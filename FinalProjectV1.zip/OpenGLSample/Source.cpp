﻿/* Name: Gerardo Gonzalez
   Date: 10-13-2023
   SNHU: CS-300
   MileStone: 6-5 MileStone */

#include <iostream>         // cout, cerr
#include <cstdlib>          // EXIT_FAILURE

#include <glad/glad.h>
#include <GLFW/glfw3.h>

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "shader.h"
#include "camera.h"
#include "cylinder.h"
#include "sphere.h"
#include <iostream>

void framebuffer_size_callback(GLFWwindow* window, int width, int height);
void mouse_callback(GLFWwindow* window, double xpos, double ypos);
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset);
void processInput(GLFWwindow *window);
bool ortho = false;
unsigned int loadTexture(const char *path);

// settings
const unsigned int SCR_WIDTH = 800;
const unsigned int SCR_HEIGHT = 600;

// camera
Camera camera(glm::vec3(0.0f, 0.0f, 3.0f));
float lastX = SCR_WIDTH / 2.0f;
float lastY = SCR_HEIGHT / 2.0f;
bool firstMouse = true;

// timing
float deltaTime = 0.0f;
float lastFrame = 0.0f;

// lighting
glm::vec3 lightPos(1.0f, 2.0f, 2.0f);

int main() {
	// glfw: initialize and configure
	// ------------------------------
	glfwInit();
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

	// glfw window creation
	// --------------------
	GLFWwindow* window = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT, "Gerardo Gonzalez", NULL, NULL);
	if (window == NULL) {
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return -1;
	}
	glfwMakeContextCurrent(window);
	glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
	glfwSetCursorPosCallback(window, mouse_callback);
	glfwSetScrollCallback(window, scroll_callback);


	// tell GLFW to capture our mouse
	glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

	// glad: load all OpenGL function pointers
	// ---------------------------------------
	if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress)) {
		std::cout << "Failed to initialize GLAD" << std::endl;
		return -1;
	}

	// configure global opengl state
	// -----------------------------
	glEnable(GL_DEPTH_TEST);

	// build and compile our shader zprogram
	// ------------------------------------
	Shader lightShader("shaderfiles/6.multiple_lights.vs", "shaderfiles/6.multiple_lights.fs");
	Shader cubeShader("shaderfiles/6.light_cube.vs", "shaderfiles/6.light_cube.fs");

	// set up vertex data (and buffer(s)) and configure vertex attributes
	// ------------------------------------------------------------------
	
	GLfloat nOfT = 1.0f;

	float triVerts[] = {
	//------ vertices ---------- Color ---------- Texture ----- Vert Position

	  // top 
	   0.23f,  0.3f, 0.0f,      0.0f, 0.0f, -1.0f,   nOfT, 0.0f, // bottom right
	  -0.23f,  0.3f, 0.0f,      0.0f, 0.0f, -1.0f,   0.0f, 0.0f, // bottom left
	   0.00f,  0.4f, 0.044f,    0.0f, 0.0f, -1.0f,   0.5f, 1.0f,

	   0.00f,  0.4f, 0.044f,    0.0f, 0.0f, -1.0f,   0.5f, 1.0f,
	   0.06f,  0.4f, 0.06f,     0.0f, 0.0f, -1.0f,   0.5f, 1.0f,
	   0.23f,  0.3f, 0.0f,      0.0f, 0.0f, -1.0f,   nOfT, 0.0f, // bottom right

	   0.23f,  0.3f, 0.0f,      1.0f, 0.0f, 0.0f,   nOfT, 0.0f, // bottom right
	   0.06f,  0.4f, 0.06f,     1.0f, 0.0f, 0.0f,   0.5f, 1.0f,
	   0.07f,  0.4f, 0.095f,    1.0f, 0.0f, 0.0f,   0.5f, 1.0f,

		0.23f,  0.3f, 0.0f,     1.0f, 0.0f, 0.0f,    nOfT, 0.0f, // bottom right
	    0.07f,  0.4f, 0.095f,   1.0f, 0.0f, 0.0f,    0.5f, 1.0f,
		0.23f,  0.3f, 0.2f,     1.0f, 0.0f, 0.0f,    0.0f, 0.0f, // 

		0.23f,  0.3f, 0.2f,     1.0f, 0.0f, 0.0f,    nOfT, nOfT, // 
		0.07f,  0.4f, 0.095f,   1.0f, 0.0f, 0.0f,    0.5f, 1.0f,
		0.05f,  0.4f, 0.15f,    1.0f, 0.0f, 0.0f,    0.5f, 1.0f,

		0.00f,  0.4f, 0.165f,   1.0f, 0.0f, 0.0f,    0.5f, 1.0f,
		0.05f,  0.4f, 0.15f,    1.0f, 0.0f, 0.0f,    0.0f, 1.0f,
		0.23f,  0.3f, 0.2f,     1.0f, 0.0f, 0.0f,    nOfT, nOfT, // 

		0.23f,  0.3f,  0.2f,    0.0f, 0.0f, 1.0f,    1.0f, 0.0f, // 
	   -0.23f,  0.3f,  0.2f,    0.0f, 0.0f, 1.0f,    0.0f, 1.0f, // bottom left
	    0.00f,  0.4f,  0.165f,  0.0f, 0.0f, 1.0f,    nOfT, nOfT,

	   -0.23f,  0.3f,  0.0f,   -1.0f, 0.0f, 0.0f,    0.0f, 0.0f, // bottom left
	   -0.23f,  0.3f,  0.2f,   -1.0f, 0.0f, 0.0f,    1.0f, 0.0f,
	   -0.075f,  0.4f, 0.095f, -1.0f, 0.0f, 0.0f,    0.5f, 1.0f, // point 

	   -0.23f,  0.3f, 0.0f,    -1.0f, 0.0f, 0.0f,    0.0f, 0.0f, // bottom left
	   -0.06f,  0.4f, 0.05f,   -1.0f, 0.0f, 0.0f,    0.5f, 1.0f, // point 
		0.00f,  0.4f, 0.044f,  -1.0f, 0.0f, 0.0f,    0.5f, 1.0f,

	   -0.23f,  0.3f,  0.0f,   -1.0f, 0.0f, 0.0f,    0.0f, 0.0f, // bottom left
	   -0.06f,  0.4f,  0.05f,  -1.0f, 0.0f, 0.0f,    0.0f, 1.0f, // point 
	   -0.075f,  0.4f, 0.095f, -1.0f, 0.0f, 0.0f,    0.5f, 1.0f, // point 

	   -0.23f,  0.3f, 0.2f,     0.0f, 0.0f, 1.0f,    nOfT, nOfT, // bottom right
	    0.00f,  0.4f, 0.165f,   0.0f, 0.0f, 1.0f,    0.5f, 1.0f,
	   -0.055f,  0.4f, 0.14f,   0.0f, 0.0f, 1.0f,    0.5f, 1.0f,

	   -0.23f,  0.3f, 0.2f,    -1.0f, 0.0f, 0.0f,    nOfT, 0.0f, // bottom right
	   -0.075f,  0.4f, 0.095f, -1.0f, 0.0f, 0.0f,    0.5f, 1.0f, // point 
	   -0.055f,  0.4f, 0.14f,  -1.0f, 0.0f, 0.0f,    0.5f, 1.0f,

	    // ---- Back Face ----
		0.23f,  0.3f, 0.0f,   0.0f, 0.0f, -1.0f,   nOfT, nOfT, // top right
	   -0.23f,  0.3f, 0.0f,   0.0f, 0.0f, -1.0f,   0.0f, nOfT, // top left
	   -0.23f, -0.3f, 0.0f,   0.0f, 0.0f, -1.0f,   0.0f, 0.0f, // bottom left 
		0.23f,  0.3f, 0.0f,   0.0f, 0.0f, -1.0f,   nOfT, nOfT, // top right  
		0.23f, -0.3f, 0.0f,   0.0f, 0.0f, -1.0f,   nOfT, 0.0f, // bottom right 
	   -0.23f, -0.3f, 0.0f,   0.0f, 0.0f, -1.0f,   0.0f, 0.0f, // bottom left 

	    // ---- Front Face ----
		0.23f,  0.3f, 0.2f,   0.0f, 0.0f, 1.0f,   nOfT, nOfT, // top right 
	   -0.23f,  0.3f, 0.2f,   0.0f, 0.0f, 1.0f,   0.0f, nOfT, // top left 
	   -0.23f, -0.3f, 0.2f,   0.0f, 0.0f, 1.0f,   0.0f, 0.0f, // bottom left
		0.23f,  0.3f, 0.2f,   0.0f, 0.0f, 1.0f,   nOfT, nOfT, // top right 
		0.23f, -0.3f, 0.2f,   0.0f, 0.0f, 1.0f,   nOfT, 0.0f, // bottom right 
	   -0.23f, -0.3f, 0.2f,   0.0f, 0.0f, 1.0f,   0.0f, 0.0f, // bottom left

	    // ----- Base ----- 
		0.23f, -0.3f, 0.0f,   0.0f, -1.0f, 0.0f,   nOfT, 0.0f, // bottom right
		0.23f, -0.3f, 0.2f,   0.0f, -1.0f, 0.0f,   nOfT, nOfT, // top right
	   -0.23f, -0.3f, 0.0f,   0.0f, -1.0f, 0.0f,   0.0f, 0.0f, // bottom left
	   -0.23f, -0.3f, 0.0f,   0.0f, -1.0f, 0.0f,   0.0f, 0.0f, // bottom left 
	   -0.23f, -0.3f, 0.2f,   0.0f, -1.0f, 0.0f,   0.0f, nOfT, // top left
		0.23f, -0.3f, 0.2f,   0.0f, -1.0f, 0.0f,   nOfT, nOfT, // top right 

		// ---- right side ----
		0.23f,  0.3f, 0.0f,   1.0f, 0.0f, 0.0f,   nOfT, nOfT, // 
		0.23f,  0.3f, 0.2f,   1.0f, 0.0f, 0.0f,   0.0f, nOfT, // 
		0.23f, -0.3f, 0.0f,   1.0f, 0.0f, 0.0f,   nOfT, 0.0f, // 

		0.23f, -0.3f, 0.0f,   1.0f, 0.0f, 0.0f,   nOfT, 0.0f, // 
		0.23f, -0.3f, 0.2f,   1.0f, 0.0f, 0.0f,   0.0f, 0.0f, // 
		0.23f,  0.3f, 0.2f,   1.0f, 0.0f, 0.0f,   0.0f, nOfT, // 

		// ---- left side ----
		-0.23f,  0.3f, 0.0f,  -1.0f, 0.0f, 0.0f,   nOfT, nOfT, // 
		-0.23f,  0.3f, 0.2f,  -1.0f, 0.0f, 0.0f,   0.0f, nOfT, // 
		-0.23f, -0.3f, 0.0f,  -1.0f, 0.0f, 0.0f,   nOfT, 0.0f, // 

		-0.23f, -0.3f, 0.0f,  -1.0f, 0.0f, 0.0f,   nOfT, 0.0f, // 
		-0.23f, -0.3f, 0.2f,  -1.0f, 0.0f, 0.0f,   0.0f, 0.0f, // 
		-0.23f,  0.3f, 0.2f,  -1.0f, 0.0f, 0.0f,   0.0f, nOfT, // 
	};



	GLfloat cubeLight[]{
		// positions          // normals           // texture coords
		-0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f,  0.0f,
		 0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f,  0.0f,
		 0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f,  1.0f,
		 0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f,  1.0f,
		-0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f,  1.0f,
		-0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f,  0.0f,

		-0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f,  0.0f,
		 0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f,  0.0f,
		 0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f,  1.0f,
		 0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f,  1.0f,
		-0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f,  1.0f,
		-0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f,  0.0f,

		-0.5f,  0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  1.0f,  0.0f,
		-0.5f,  0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  1.0f,  1.0f,
		-0.5f, -0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  0.0f,  1.0f,
		-0.5f, -0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  0.0f,  1.0f,
		-0.5f, -0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  0.0f,  0.0f,
		-0.5f,  0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  1.0f,  0.0f,

		 0.5f,  0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  1.0f,  0.0f,
		 0.5f,  0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  1.0f,  1.0f,
		 0.5f, -0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  0.0f,  1.0f,
		 0.5f, -0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  0.0f,  1.0f,
		 0.5f, -0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  0.0f,  0.0f,
		 0.5f,  0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  1.0f,  0.0f,

		-0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,  0.0f,  1.0f,
		 0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,  1.0f,  1.0f,
		 0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,  1.0f,  0.0f,
		 0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,  1.0f,  0.0f,
		-0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,  0.0f,  0.0f,
		-0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,  0.0f,  1.0f,

		-0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,  0.0f,  1.0f,
		 0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,  1.0f,  1.0f,
		 0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,  1.0f,  0.0f,
		 0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,  1.0f,  0.0f,
		-0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,  0.0f,  0.0f,
		-0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,  0.0f,  1.0f
	};
	/**************************************** Vertex Data Minipulation and handeling  *******************************************/
	// Declars an vertex buffer object and vertex array object (I want)
	GLuint VBO, VAO;
	GLuint VBO1, VAO1;
	GLuint VBO2, VAO2;
	GLuint lightVAO, LightVBO;

	// Generates both objects (I have)
	glGenVertexArrays(1, &VAO);
	glGenBuffers(1, &VBO);

	// binds buffer object aka grabs the object.
	glBindBuffer(GL_ARRAY_BUFFER, VBO);
	// this is when you actually put the data into the object.
	glBufferData(GL_ARRAY_BUFFER, sizeof(triVerts), triVerts, GL_STATIC_DRAW);

	// binds/ uses the spefict object to use ( I Grab)
	glBindVertexArray(VAO);
	

	// This tells the us how to interpretate the data from the VBO. 
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
	
	// specifices the what index to start aka where do we start from.
	glEnableVertexAttribArray(0);

	//This is for the normal cordinates
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);

	// This is for the texture coordinates 
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
	glEnableVertexAttribArray(2);


	//=================== cylinder ? ======================
	glGenVertexArrays(1, &VAO2);
	glGenBuffers(1, &VBO2);
	glBindVertexArray(VAO2);
	glBindBuffer(GL_ARRAY_BUFFER, VBO2);


	//====================== light ========================
	
	// Light data and buffer configuration 
	glGenVertexArrays(1, &lightVAO);
	glGenBuffers(1, &LightVBO);

	glBindBuffer(GL_ARRAY_BUFFER, LightVBO);
	glBufferData(GL_ARRAY_BUFFER, sizeof(cubeLight), cubeLight, GL_STATIC_DRAW);

	glBindVertexArray(lightVAO);
	// This tells the us how to interpretate the data from the VBO. 
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
	// specifices the what index to start aka where do we start from.
	glEnableVertexAttribArray(0);

	//This is for the normal cordinates
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);

	// This is for the texture coordinates 
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
	glEnableVertexAttribArray(2);


	/***************************** Texture Loading and Minipulating*********************************/
	
	// Declares a texture object (I want)
	GLuint texture, texture1, texture2, texture3, texture4;


	// Actully creates a texture (I have)
	glGenTextures(1, &texture);

	// Specifices the current texture being used (I Grab)
	glBindTexture(GL_TEXTURE_2D, texture);

	// Sets the texture wrap type
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

	// Sets the texture filters 
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	// declares some variable parameters
	int width, height, channels;
	stbi_set_flip_vertically_on_load(true);
	// creates and texture data and loads the data from file path in dir
	unsigned char* texData = stbi_load("media/handsanitizer.png", &width, &height, &channels, 0);

	// condition checking for the type of data in the texture data.
	if (texData) {
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, texData);
		glGenerateMipmap(GL_TEXTURE_2D);
	}
	else {
		std::cout << "Failed to load texture" << std::endl;
	}

	// frees the image/image data from the texture data.
	stbi_image_free(texData);



	// ------------ Texture 2 ---------------

	// Actully creates a texture (I have)
	glGenTextures(1, &texture1);

	// Specifices the current texture being used (I Grab)
	glBindTexture(GL_TEXTURE_2D, texture1);

	// Sets the texture wrap type
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

	// Sets the texture filters 
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	// declares some variable parameters
	// creates and texture data and loads the data from file path in dir
	texData = stbi_load("media/capTexture.png", &width, &height, &channels, 0);

	// condition checking for the type of data in the texture data.
	if (texData) {
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, texData);
		glGenerateMipmap(GL_TEXTURE_2D);
	}
	else {
		std::cout << "Failed to load texture" << std::endl;
	}
	// frees the image/image data from the texture data.
	stbi_image_free(texData);
	
	// ------------ Texture 3 ---------------

	// Actully creates a texture (I have)
	glGenTextures(1, &texture2);

	// Specifices the current texture being used (I Grab)
	glBindTexture(GL_TEXTURE_2D, texture2);

	// Sets the texture wrap type
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

	// Sets the texture filters 
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	// declares some variable parameters
	stbi_set_flip_vertically_on_load(true);
	// creates and texture data and loads the data from file path in dir
	texData = stbi_load("media/surface.png", &width, &height, &channels, 0);

	// condition checking for the type of data in the texture data.
	if (texData) {
		// Note that the table is not transparent and is an all white table thus resulting in a RGB instead of an RGBA
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, texData);
		glGenerateMipmap(GL_TEXTURE_2D);
	}
	else {
		std::cout << "Failed to load texture" << std::endl;
	}
	// frees the image/image data from the texture data.
	stbi_image_free(texData);

	// ------------ Texture 4 ---------------

	// Actully creates a texture (I have)
	glGenTextures(1, &texture3);

	// Specifices the current texture being used (I Grab)
	glBindTexture(GL_TEXTURE_2D, texture3);

	// Sets the texture wrap type
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

	// Sets the texture filters 
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	// declares some variable parameters
	stbi_set_flip_vertically_on_load(true);
	// creates and texture data and loads the data from file path in dir
	texData = stbi_load("media/surface.jpg", &width, &height, &channels, 0);

	// condition checking for the type of data in the texture data.
	if (texData) {
		// Note that the table is not transparent and is an all white table thus resulting in a RGB instead of an RGBA
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, texData);
		glGenerateMipmap(GL_TEXTURE_2D);
	}
	else {
		std::cout << "Failed to load texture" << std::endl;
	}
	// frees the image/image data from the texture data.
	stbi_image_free(texData);

	// ------------ Texture 5 ---------------

	// Actully creates a texture (I have)
	glGenTextures(1, &texture4);

	// Specifices the current texture being used (I Grab)
	glBindTexture(GL_TEXTURE_2D, texture4);

	// Sets the texture wrap type
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

	// Sets the texture filters 
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	// declares some variable parameters
	stbi_set_flip_vertically_on_load(true);
	// creates and texture data and loads the data from file path in dir
	texData = stbi_load("media/tableTop.jpg", &width, &height, &channels, 0);

	// condition checking for the type of data in the texture data.
	if (texData) {
		// Note that the table is not transparent and is an all white table thus resulting in a RGB instead of an RGBA
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, texData);
		glGenerateMipmap(GL_TEXTURE_2D);
	}
	else {
		std::cout << "Failed to load texture" << std::endl;
	}
	// frees the image/image data from the texture data.
	stbi_image_free(texData);

	//// diffrenet way to set and minipulate textures
	//lightShader.use();
	//glUniform1i(glGetUniformLocation(lightShader.ID, "texture"), 0);
	lightShader.use();
	lightShader.setInt("texture", 0);
	lightShader.setInt("texture1", 1);
	lightShader.setInt("texture2", 2);
	lightShader.setInt("texture3", 3);

	glm::mat4 model;
	GLfloat angle;

	// Creates shapes once to save memory utilization.
	static_meshes_3D::Cylinder C1(0.41, 16, 1.2, true, true, true);
	static_meshes_3D::Sphere S1(0.45, 16, 16, true, true, true);

	// render loop
	// -----------
	while (!glfwWindowShouldClose(window)) {
		// per-frame time logic
		// --------------------
		float currentFrame = glfwGetTime();
		deltaTime = currentFrame - lastFrame;
		lastFrame = currentFrame;

		// input
		// -----
		processInput(window);

		// render
		// ------
		glClearColor(0.1f, 0.3f, 0.2f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		// view projecttion selection logic, this logic selectes which view projection to use. Ortho vs perspective. 
		glm::mat4 projection;
		
		if (ortho) {
			float orthoScale = 10;
			projection = glm::ortho(-((float)camera.Zoom) / orthoScale, ((float)camera.Zoom) / orthoScale, -1.0f, 5.5f, -10.0f, 10.0f);
		}
		else {
			projection = glm::perspective(glm::radians(camera.Zoom), (GLfloat)SCR_WIDTH / (GLfloat)SCR_HEIGHT, 0.1f, 100.0f);
		}


		lightShader.use();
		lightShader.setVec3("viewPos", camera.Position);
		lightShader.setFloat("material.shininess", 32.0f);
		// directional light blueish color to mimic selected window light.
		lightShader.setVec3("dirLight.direction", -0.6f, -0.1f, -0.3f);
		lightShader.setVec3("dirLight.ambient", 0.6f, 0.6f, 0.6f);
		lightShader.setVec3("dirLight.diffuse", 0.0f, 0.0f, 0.5f);
		lightShader.setVec3("dirLight.specular", 0.0f, 0.0f, 0.5f);

		// point light selected a warm light color to mimic light bulb.
		lightShader.setVec3("pointLights[0].position", lightPos);
		lightShader.setVec3("pointLights[0].ambient", 0.05f, 0.05f, 0.05f);
		lightShader.setVec3("pointLights[0].diffuse", 1.0f, 0.8f, 0.5f);
		lightShader.setVec3("pointLights[0].specular", 1.0f, 0.8f, 0.5f);
		lightShader.setFloat("pointLights[0].constant", 1.0f);
		lightShader.setFloat("pointLights[0].linear", 0.09);
		lightShader.setFloat("pointLights[0].quadratic", 0.032);

		// this is just green to illistrate the color of a flashlight. 
		lightShader.setVec3("spotLight.position", camera.Position);
		lightShader.setVec3("spotLight.direction", camera.Front);
		lightShader.setVec3("spotLight.ambient", 0.0f, 0.0f, 0.0f);
		lightShader.setVec3("spotLight.diffuse", 0.0f, 0.5f, 0.0f);
		lightShader.setVec3("spotLight.specular", 1.0f, 1.0f, 1.0f);
		lightShader.setFloat("spotLight.constant", 1.0f);
		lightShader.setFloat("spotLight.linear", 0.09);
		lightShader.setFloat("spotLight.quadratic", 0.032);
		lightShader.setFloat("spotLight.cutOff", glm::cos(glm::radians(12.5f)));
		lightShader.setFloat("spotLight.outerCutOff", glm::cos(glm::radians(15.0f)));

		
		lightShader.use();
		lightShader.setMat4("projection", projection);

		glm::mat4 view = camera.GetViewMatrix();
		lightShader.setMat4("view", view);
 
		// this controls the first object which is bottle of hand sanitizer.		
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, texture);
		glBindVertexArray(VAO);
		model = glm::mat4(1.0f);
		model = glm::translate(model, glm::vec3(-1.1f, 0.010f, 0.5f));
		angle = 75.56f;
		model = glm::rotate(model, glm::radians(angle), glm::vec3(0.0f, 1.0f, 0.0f));
		lightShader.setMat4("model", model);
		glDrawArrays(GL_TRIANGLES, 0, sizeof(triVerts));
		glBindVertexArray(0);

		// This is the hand santizer cap 
		glBindVertexArray(VAO2);
		model = glm::mat3(1.0f);
		glBindTexture(GL_TEXTURE_2D, texture1);
		model = glm::translate(model, glm::vec3(-1.0f, 0.47f, 0.5f)); 
		model = glm::scale(model, glm::vec3(0.2f));
		lightShader.setMat4("model", model);
		C1.render();
		glBindVertexArray(0);

		// This is the red ball 
		glBindVertexArray(VAO2);
		model = glm::mat3(1.0f);
		glBindTexture(GL_TEXTURE_2D, texture3);
		model = glm::translate(model, glm::vec3(-0.17f, 0.155f, 1.0f));
		model = glm::scale(model, glm::vec3(1.0f));
		lightShader.setMat4("model", model);
		S1.render();
		glBindVertexArray(0);
		glBindTexture(GL_TEXTURE_2D, 0);

		// This is the table 
		glBindVertexArray(lightVAO);
		model = glm::mat4(1.0f);
		glBindTexture(GL_TEXTURE_2D, texture2);
		model = glm::translate(model, glm::vec3(0.0f, -0.395f, 0.9f));
		model = glm::scale(model, glm::vec3(3.5f, 0.2f, 2.6f));
		lightShader.setMat4("model", model);
		glDrawArrays(GL_TRIANGLES, 0, sizeof(cubeLight));
		glBindVertexArray(0);

		// This is the top of the abstract box
		glBindVertexArray(lightVAO);
		model = glm::mat3(1.0f);
		glBindTexture(GL_TEXTURE_2D, texture4);
		model = glm::translate(model, glm::vec3(0.55f, -0.05f, 1.8f));
		model = glm::scale(model, glm::vec3(0.75f, 0.4f, 0.4f));
		lightShader.setMat4("model", model);
		glDrawArrays(GL_TRIANGLES, 0, sizeof(cubeLight));
		glBindVertexArray(0);

		// this is the bottom of the abstract box 
		glBindVertexArray(lightVAO);
		model = glm::mat3(1.0f);
		glBindTexture(GL_TEXTURE_2D, texture4);
		model = glm::translate(model, glm::vec3(0.55f, -0.1f, 1.8f));
		model = glm::scale(model, glm::vec3(0.7f, 0.38f, 0.38f));
		lightShader.setMat4("model", model);
		glDrawArrays(GL_TRIANGLES, 0, sizeof(cubeLight));
		glBindVertexArray(0);

		cubeShader.use();
		cubeShader.setMat4("projection", projection);
		cubeShader.setMat4("view", view);

		// light bulb
		glBindVertexArray(lightVAO);
		model = glm::mat4(1.0f);
		model = glm::translate(model, lightPos);
		model = glm::scale(model, glm::vec3(0.2f));
		cubeShader.setMat4("model", model);
		glDrawArrays(GL_TRIANGLES, 0, sizeof(cubeLight));
		glBindVertexArray(0);



		// glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
		// -------------------------------------------------------------------------------
		glfwSwapBuffers(window);
		glfwPollEvents();
	}

	// optional: de-allocate all resources once they've outlived their purpose:
	// ------------------------------------------------------------------------
	glDeleteVertexArrays(1, &VAO);
	glDeleteBuffers(1, &VBO);

	glDeleteVertexArrays(1, &VAO1);
	glDeleteBuffers(1, &VBO1);
	// glfw: terminate, clearing all previously allocated GLFW resources.
	// ------------------------------------------------------------------
	glfwTerminate();
	return 0;
}

// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
// ---------------------------------------------------------------------------------------------------------
void processInput(GLFWwindow *window) {
	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
		glfwSetWindowShouldClose(window, true);

	if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
		camera.ProcessKeyboard(FORWARD, deltaTime);
	if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
		camera.ProcessKeyboard(BACKWARD, deltaTime);
	if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
		camera.ProcessKeyboard(LEFT, deltaTime);
	if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
		camera.ProcessKeyboard(RIGHT, deltaTime);

	// Lets the user ascend and decend. 
	if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
		camera.ProcessKeyboard(UP, deltaTime);
	if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
		camera.ProcessKeyboard(DOWN, deltaTime);

	// Controls the ortho view condition, ortho is true or false based on press.
	if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS)
		ortho = !ortho;
}

// glfw: whenever the window size changed (by OS or user resize) this callback function executes
// ---------------------------------------------------------------------------------------------
void framebuffer_size_callback(GLFWwindow* window, int width, int height) {
	// make sure the viewport matches the new window dimensions; note that width and 
	// height will be significantly larger than specified on retina displays.
	glViewport(0, 0, width, height);
}

// glfw: whenever the mouse moves, this callback is called
// -------------------------------------------------------
void mouse_callback(GLFWwindow* window, double xpos, double ypos) {
	if (firstMouse)
	{
		lastX = xpos;
		lastY = ypos;
		firstMouse = false;
	}

	float xoffset = xpos - lastX;
	float yoffset = lastY - ypos; // reversed since y-coordinates go from bottom to top

	lastX = xpos;
	lastY = ypos;

	camera.ProcessMouseMovement(xoffset, yoffset);
}

// glfw: whenever the mouse scroll wheel scrolls, this callback is called
// ----------------------------------------------------------------------
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset) {
	camera.ProcessMouseScroll(yoffset);
}

// loaded texture but not used/ expirementing.
unsigned int loadTexture(char const* path)
{
	unsigned int textureID;
	glGenTextures(1, &textureID);

	int width, height, nrComponents;
	unsigned char* data = stbi_load(path, &width, &height, &nrComponents, 0);
	if (data)
	{
		GLenum format;
		if (nrComponents == 1)
			format = GL_RED;
		else if (nrComponents == 3)
			format = GL_RGB;
		else if (nrComponents == 4)
			format = GL_RGBA;

		glBindTexture(GL_TEXTURE_2D, textureID);
		glTexImage2D(GL_TEXTURE_2D, 0, format, width, height, 0, format, GL_UNSIGNED_BYTE, data);
		glGenerateMipmap(GL_TEXTURE_2D);

		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		stbi_image_free(data);
	}
	else
	{
		std::cout << "Texture failed to load at path: " << path << std::endl;
		stbi_image_free(data);
	}

	return textureID;
}